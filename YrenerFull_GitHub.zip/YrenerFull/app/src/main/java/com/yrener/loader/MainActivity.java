package com.yrener.loader;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;

public class MainActivity extends Activity {

    // ===== КОНСТАНТЫ =====
    static final String API      = "http://bot-yrener-production.up.railway.app/check_key?key=";
    static final String TG_CH    = "https://t.me/Yrener_Soft";
    static final String TG_BOT   = "https://t.me/Yrener_Freebot";
    static final String SITE     = "https://yrenercc.netlify.app";
    static final String PREFS    = "yrener";

    // ===== STATE =====
    SharedPreferences prefs;
    String curLang = "ru";
    String curTheme = "dark";
    String userEmail = "";
    String activeKey = "";
    long keyExpire = 0;
    CountDownTimer keyTimer;
    int curTab = 0; // 0=home,1=faq,2=profile,3=settings

    // ===== VIEWS =====
    // Экраны
    LinearLayout screenWelcome, screenLogin, screenKey, screenApp;
    // Нав бар
    LinearLayout navBar;
    Button navHome, navFaq, navProfile, navSettings;
    // Таб контент
    LinearLayout tabHome, tabFaq, tabProfile, tabSettings;
    // Таймер
    TextView mainTimer, mainKeyShow;
    // Профиль
    TextView profileEmail, profileDevice, profileDate, profileKeyVal, profileKeyTime;
    // Статус
    TextView loginStatus, keyStatus;
    // Настройки
    LinearLayout langGrid, themeGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.parseColor("#08080F"));
        setContentView(buildUI());

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        curTheme = prefs.getString("theme", "dark");
        curLang  = prefs.getString("lang", "ru");
        userEmail = prefs.getString("email", "");
        activeKey = prefs.getString("key", "");
        keyExpire = prefs.getLong("expire", 0);

        applyTheme();

        if (!userEmail.isEmpty()) {
            if (!activeKey.isEmpty() && keyExpire > now()) {
                showApp();
            } else {
                showScreen(screenKey);
            }
        } else {
            showScreen(screenWelcome);
        }
    }

    long now() { return System.currentTimeMillis() / 1000; }

    // =============================================
    // BUILD UI PROGRAMMATICALLY
    // =============================================
    ScrollView rootScroll;
    LinearLayout rootLayout;

    View buildUI() {
        rootScroll = new ScrollView(this);
        rootScroll.setFillViewport(true);

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

        screenWelcome = buildWelcomeScreen();
        screenLogin   = buildLoginScreen();
        screenKey     = buildKeyScreen();
        screenApp     = buildAppScreen();

        rootLayout.addView(screenWelcome);
        rootLayout.addView(screenLogin);
        rootLayout.addView(screenKey);
        rootLayout.addView(screenApp);

        rootScroll.addView(rootLayout);
        return rootScroll;
    }

    // ===== WELCOME =====
    LinearLayout buildWelcomeScreen() {
        LinearLayout s = screen();
        s.setGravity(Gravity.CENTER);
        s.setPadding(dp(28), dp(60), dp(28), dp(40));

        s.addView(logoFull("⚡ МЕНЮ НОВОГО ПОКОЛЕНИЯ"));

        LinearLayout card = card();
        card.addView(cardTitle("Добро пожаловать"));
        card.addView(cardSub("Войди или зарегистрируйся через сайт"));
        space(card, 16);

        Button reg = btn("✨  Зарегистрироваться", "primary");
        reg.setOnClickListener(v -> startRegisterFlow());
        card.addView(reg);
        space(card, 8);

        card.addView(divider("или"));
        space(card, 8);

        Button login = btn("🔐  Войти в аккаунт", "glass");
        login.setOnClickListener(v -> showScreen(screenLogin));
        card.addView(login);
        space(card, 8);

        Button tg = btn("✈️  Telegram канал", "tg");
        tg.setOnClickListener(v -> openUrl(TG_CH));
        card.addView(tg);
        space(card, 12);

        TextView note = txt("Регистрация только через сайт", 12, "#555566");
        note.setGravity(Gravity.CENTER);
        card.addView(note);

        s.addView(card);
        space(s, 12);
        s.addView(txt("Yrener Menu v1.4", 11, "#444455"));

        return s;
    }

    // ===== LOGIN =====
    LinearLayout buildLoginScreen() {
        LinearLayout s = screen();
        s.setGravity(Gravity.CENTER);
        s.setPadding(dp(28), dp(60), dp(28), dp(40));
        s.addView(logoFull("Войти в аккаунт"));

        LinearLayout card = card();
        card.addView(inputLabel("Email"));
        EditText emailField = inputField("your@email.com", false);
        card.addView(emailField);
        space(card, 10);
        card.addView(inputLabel("Пароль"));
        EditText passField = inputField("••••••••", true);
        card.addView(passField);
        space(card, 12);

        loginStatus = txt("", 13, "#888899");
        card.addView(loginStatus);
        space(card, 4);

        Button loginBtn = btn("Войти", "primary");
        loginBtn.setOnClickListener(v -> doLogin(emailField, passField));
        card.addView(loginBtn);
        space(card, 8);
        card.addView(divider("или"));
        space(card, 8);

        Button googleBtn = btn("🔍  Войти через Google", "glass");
        googleBtn.setOnClickListener(v -> openUrl(SITE + "/#google"));
        card.addView(googleBtn);

        s.addView(card);
        space(s, 12);

        LinearLayout row = row();
        TextView noAcc = txt("Нет аккаунта? ", 14, "#888899");
        TextView regLink = txt("Зарегистрироваться", 14, "#A78BFA");
        regLink.setOnClickListener(v -> startRegisterFlow());
        row.addView(noAcc);
        row.addView(regLink);
        s.addView(row);
        space(s, 10);

        Button back = btn("← Назад", "glass");
        back.setOnClickListener(v -> showScreen(screenWelcome));
        s.addView(back);

        return s;
    }

    // ===== KEY SCREEN =====
    LinearLayout buildKeyScreen() {
        LinearLayout s = screen();
        s.setGravity(Gravity.CENTER);
        s.setPadding(dp(28), dp(60), dp(28), dp(40));
        s.addView(logoFull("Активация"));

        LinearLayout card = card();
        card.addView(cardTitle("Введи ключ доступа"));
        card.addView(cardSub("Получи ключ в нашем Telegram боте"));
        space(card, 16);

        Button botBtn = btn("✈️  Получить ключ в боте", "tg");
        botBtn.setOnClickListener(v -> keyCountdown());
        card.addView(botBtn);
        space(card, 12);
        card.addView(divider("— или введи ключ —"));
        space(card, 12);

        EditText keyField = inputField("Например: AB1.CD", false);
        keyField.setTypeface(Typeface.MONOSPACE);
        keyField.setLetterSpacing(0.1f);
        card.addView(keyField);
        space(card, 10);

        keyStatus = txt("", 13, "#888899");
        card.addView(keyStatus);
        space(card, 4);

        Button activateBtn = btn("🔑  Активировать ключ", "white");
        activateBtn.setOnClickListener(v -> {
            String k = keyField.getText().toString().trim();
            checkKey(k, activateBtn);
        });
        card.addView(activateBtn);
        s.addView(card);

        return s;
    }

    void keyCountdown() {
        keyStatus.setText("⏳ Переход через 5 сек...");
        new CountDownTimer(5000, 1000) {
            int c = 5;
            public void onTick(long ms) { c--; keyStatus.setText("⏳ Переход через " + c + " сек..."); }
            public void onFinish() { keyStatus.setText("Вернись и введи ключ из бота"); openUrl(TG_BOT); }
        }.start();
    }

    // ===== APP SCREEN =====
    LinearLayout buildAppScreen() {
        LinearLayout s = new LinearLayout(this);
        s.setOrientation(LinearLayout.VERTICAL);
        s.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        s.setVisibility(View.GONE);

        // Таб контенты
        tabHome     = buildTabHome();
        tabFaq      = buildTabFaq();
        tabProfile  = buildTabProfile();
        tabSettings = buildTabSettings();

        s.addView(tabHome);
        s.addView(tabFaq);
        s.addView(tabProfile);
        s.addView(tabSettings);

        // Навбар
        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setBackgroundColor(Color.parseColor("#0D0D1A"));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, dp(60));
        navBar.setLayoutParams(np);

        navHome     = navBtn("🏠", "Главная");
        navFaq      = navBtn("❓", "FAQ");
        navProfile  = navBtn("👤", "Профиль");
        navSettings = navBtn("⚙️", "Настройки");

        navHome.setOnClickListener(v -> showTab(0));
        navFaq.setOnClickListener(v -> showTab(1));
        navProfile.setOnClickListener(v -> showTab(2));
        navSettings.setOnClickListener(v -> showTab(3));

        navBar.addView(navHome);
        navBar.addView(navFaq);
        navBar.addView(navProfile);
        navBar.addView(navSettings);

        s.addView(navBar);
        return s;
    }

    // ===== TAB HOME =====
    LinearLayout buildTabHome() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(20), dp(16), dp(20), dp(8));

        // Шапка
        LinearLayout header = row();
        LinearLayout logoSm = logoSmall();
        header.addView(logoSm);
        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1));
        header.addView(spacer);
        TextView ver = txt("v1.4", 11, "#6C63FF");
        ver.setPadding(dp(8), dp(4), dp(8), dp(4));
        ver.setBackground(roundBg("#1A1A3A", 20));
        header.addView(ver);
        t.addView(header);
        space(t, 16);

        // Карточка ключа
        LinearLayout keyCard = card();
        LinearLayout keyRow = row();
        TextView keyTitle = txt("🔑 Активный ключ", 15, "#FFFFFF");
        keyTitle.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams ktp = new LinearLayout.LayoutParams(0, -2, 1);
        keyTitle.setLayoutParams(ktp);
        keyRow.addView(keyTitle);
        TextView keyTag = txt("● Активен", 12, "#34D399");
        keyTag.setPadding(dp(8), dp(4), dp(8), dp(4));
        keyTag.setBackground(roundBg("#0A2A1A", 20));
        keyRow.addView(keyTag);
        keyCard.addView(keyRow);
        space(keyCard, 12);

        mainTimer = txt("00:00:00", 34, "#34D399");
        mainTimer.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        mainTimer.setGravity(Gravity.CENTER);
        mainTimer.setPadding(dp(14), dp(14), dp(14), dp(14));
        mainTimer.setBackground(roundBg("#0A1A0A", 12));
        keyCard.addView(mainTimer);
        space(keyCard, 8);

        mainKeyShow = txt("", 15, "#888899");
        mainKeyShow.setTypeface(Typeface.MONOSPACE);
        mainKeyShow.setGravity(Gravity.CENTER);
        keyCard.addView(mainKeyShow);
        t.addView(keyCard);
        space(t, 10);

        // Карточка запуска
        LinearLayout launchCard = card();
        launchCard.addView(cardTitle("🎮 Black Russia"));
        launchCard.addView(cardSub("Запусти игру с активным меню чита"));
        space(launchCard, 12);
        Button launchBtn = btn("▶  Запустить игру", "primary");
        launchBtn.setOnClickListener(v -> {
            launchBtn.setText("✅ Запущено!");
            Intent i = getPackageManager().getLaunchIntentForPackage("com.br.top");
            if (i != null) startActivity(i);
            else Toast.makeText(this, "Black Russia не установлена!", Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(() -> launchBtn.setText("▶  Запустить игру"), 3000);
        });
        launchCard.addView(launchBtn);
        t.addView(launchCard);
        space(t, 10);

        // Кнопки TG
        LinearLayout tgRow = row();
        Button ch = btn("✈ Канал", "tg");
        ch.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1));
        ch.setOnClickListener(v -> openUrl(TG_CH));
        Button bot = btn("🤖 Новый ключ", "outline_tg");
        bot.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1));
        bot.setOnClickListener(v -> openUrl(TG_BOT));
        tgRow.addView(ch);
        space2(tgRow, 8);
        tgRow.addView(bot);
        t.addView(tgRow);

        return t;
    }

    // ===== TAB FAQ =====
    LinearLayout buildTabFaq() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(20), dp(16), dp(20), dp(80));
        t.setVisibility(View.GONE);

        t.addView(pageTitle("❓ FAQ / Поддержка"));
        space(t, 12);

        Button suppBtn = btn("✈️  Написать в поддержку", "tg");
        suppBtn.setOnClickListener(v -> openUrl(TG_BOT));
        t.addView(suppBtn);
        space(t, 16);

        t.addView(sectionTitle("Частые вопросы — Игра"));
        t.addView(faqItem("Что делать если игра крашит?",
            "Перезайди в игру. Если не помогло — закрой через диспетчер задач и запусти снова. Убедись что ключ активен."));
        t.addView(faqItem("Игра не загружается?",
            "Включи VPN и попробуй снова. Попробуй серверы Германии или Нидерландов."));
        t.addView(faqItem("Меню не появляется в игре?",
            "Убедись что ключ активирован. Нажми кнопку 'Запустить игру' перед запуском. Кнопка Y появится слева на экране."));
        t.addView(faqItem("ESP не работает?",
            "Включи ESP в меню — нажми Y, включи главный переключатель ESP, затем нужные опции."));
        t.addView(faqItem("Как убрать меню во время игры?",
            "Нажми кнопку Закрыть в меню. Кнопка Y останется на экране."));

        space(t, 8);
        t.addView(sectionTitle("Частые вопросы — Бот и ключи"));
        t.addView(faqItem("Ключ не активируется?",
            "Скопируй ключ полностью без пробелов. Ключ действует 1 час — проверь не истёк ли он. Получи новый ключ в @Yrener_Freebot."));
        t.addView(faqItem("Как получить ключ?",
            "Открой бот @Yrener_Freebot и нажми Получить ключ. Ключ выдаётся на 1 час. Также можно выиграть через кубик или слоты!"));
        t.addView(faqItem("Можно ли использовать один ключ на двух устройствах?",
            "Нет — ключ привязан к одному аккаунту. Каждый получает свой ключ через бот."));
        t.addView(faqItem("Бот не отвечает?",
            "Напиши /start в бот. Если не помогло — напиши в поддержку выше или в канал @Yrener_Soft."));

        return t;
    }

    // ===== TAB PROFILE =====
    LinearLayout buildTabProfile() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(20), dp(16), dp(20), dp(80));
        t.setVisibility(View.GONE);

        t.addView(pageTitle("👤 Профиль"));
        space(t, 16);

        // Аватар
        LinearLayout avatarRow = new LinearLayout(this);
        avatarRow.setOrientation(LinearLayout.VERTICAL);
        avatarRow.setGravity(Gravity.CENTER);
        avatarRow.setPadding(0, dp(8), 0, dp(16));
        TextView avatar = txt("?", 32, "#FFFFFF");
        avatar.setTypeface(null, Typeface.BOLD);
        avatar.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams avlp = new LinearLayout.LayoutParams(dp(80), dp(80));
        avlp.gravity = Gravity.CENTER_HORIZONTAL;
        avatar.setLayoutParams(avlp);
        avatar.setBackground(roundOvalBg());
        avatarRow.addView(avatar);
        space(avatarRow, 10);
        profileEmail = txt("—", 18, "#FFFFFF");
        profileEmail.setTypeface(null, Typeface.BOLD);
        profileEmail.setGravity(Gravity.CENTER);
        avatarRow.addView(profileEmail);
        t.addView(avatarRow);

        LinearLayout card = card();
        card.addView(sectionTitle("Аккаунт"));
        card.addView(listItem("📧", "Email", "—", false));
        profileDevice = txt("—", 12, "#888899");
        card.addView(listItem("📱", "Устройство", getDeviceName(), false));
        profileDate = txt("—", 12, "#888899");
        card.addView(listItem("📅", "Дата регистрации", "—", false));
        t.addView(card);
        space(t, 10);

        LinearLayout keyCard = card();
        keyCard.addView(sectionTitle("Активный ключ"));
        profileKeyVal  = txt("—", 15, "#FFFFFF");
        profileKeyVal.setTypeface(Typeface.MONOSPACE);
        profileKeyTime = txt("Нет активного ключа", 12, "#888899");
        keyCard.addView(profileKeyVal);
        keyCard.addView(profileKeyTime);
        t.addView(keyCard);

        return t;
    }

    // ===== TAB SETTINGS =====
    LinearLayout buildTabSettings() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(20), dp(16), dp(20), dp(80));
        t.setVisibility(View.GONE);

        t.addView(pageTitle("⚙️ Настройки"));
        space(t, 12);

        // Язык
        t.addView(sectionTitle("Язык / Language"));
        langGrid = new LinearLayout(this);
        langGrid.setOrientation(LinearLayout.VERTICAL);
        String[][] langs = {{"ru","🇷🇺 Русский"},{"en","🇬🇧 English"},{"uk","🇺🇦 Українська"},{"uz","🇺🇿 O'zbek"},{"zh","🇨🇳 中文"}};
        for (String[] lang : langs) {
            Button lb = btn(lang[1], curLang.equals(lang[0]) ? "accent" : "glass");
            lb.setTag(lang[0]);
            lb.setOnClickListener(v -> {
                curLang = (String) v.getTag();
                prefs.edit().putString("lang", curLang).apply();
                rebuildLangBtns(langs);
                Toast.makeText(this, "Язык изменён", Toast.LENGTH_SHORT).show();
            });
            langGrid.addView(lb);
            space(langGrid, 6);
        }
        t.addView(langGrid);
        space(t, 12);

        // Тема
        t.addView(sectionTitle("Тема"));
        LinearLayout themeRow = row();
        Button darkBtn = btn("🌑 Тёмная", curTheme.equals("dark") ? "accent" : "glass");
        darkBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1));
        darkBtn.setOnClickListener(v -> { curTheme = "dark"; saveTheme(); applyTheme(); });
        Button lightBtn = btn("☀️ Светлая", curTheme.equals("light") ? "accent" : "glass");
        lightBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1));
        lightBtn.setOnClickListener(v -> { curTheme = "light"; saveTheme(); applyTheme(); });
        Button oceanBtn = btn("🌊 Океан", curTheme.equals("ocean") ? "accent" : "glass");
        oceanBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1));
        oceanBtn.setOnClickListener(v -> { curTheme = "ocean"; saveTheme(); applyTheme(); });
        themeRow.addView(darkBtn); space2(themeRow, 6);
        themeRow.addView(lightBtn); space2(themeRow, 6);
        themeRow.addView(oceanBtn);
        t.addView(themeRow);
        space(t, 12);

        // Аккаунт
        t.addView(sectionTitle("Аккаунт"));
        LinearLayout accCard = card();
        accCard.addView(clickItem("👤", "Мой профиль", () -> showTab(2)));
        accCard.addView(clickItem("🔑", "Сменить пароль", () -> openUrl(SITE + "/#settings")));
        accCard.addView(clickItem("🚪", "Выйти", () -> doLogout()));
        t.addView(accCard);
        space(t, 10);

        // О приложении
        t.addView(sectionTitle("О приложении"));
        LinearLayout aboutCard = card();
        aboutCard.addView(clickItem("✈️", "Telegram канал @Yrener_Soft", () -> openUrl(TG_CH)));
        aboutCard.addView(clickItem("🤖", "Telegram бот @Yrener_Freebot", () -> openUrl(TG_BOT)));
        aboutCard.addView(clickItem("⭐", "Поддержать автора", () -> showDevMsg()));
        LinearLayout verRow = row();
        TextView verL = txt("ℹ️  Версия приложения", 15, "#FFFFFF");
        verL.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        verRow.addView(verL);
        TextView verV = txt("v1.4", 12, "#A78BFA");
        verV.setPadding(dp(8), dp(4), dp(8), dp(4));
        verV.setBackground(roundBg("#1A1A3A", 20));
        verRow.addView(verV);
        verRow.setPadding(0, dp(12), 0, dp(12));
        aboutCard.addView(verRow);
        t.addView(aboutCard);

        return t;
    }

    // =============================================
    // ACTIONS
    // =============================================

    void startRegisterFlow() {
        // Показываем диалог с отсчётом
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("🌐 Регистрация через сайт");
        b.setMessage("Вы будете перенаправлены на сайт Yrener для регистрации.\n\nПосле успешной регистрации вернитесь в приложение и войдите.");
        b.setPositiveButton("Открыть сайт →", (d, w) -> openUrl(SITE));
        b.setNegativeButton("Отмена", null);
        b.show();
    }

    void doLogin(EditText emailF, EditText passF) {
        String email = emailF.getText().toString().trim();
        String pass  = passF.getText().toString();
        if (email.isEmpty() || pass.isEmpty()) {
            loginStatus.setText("❌ Заполни все поля"); loginStatus.setTextColor(Color.parseColor("#FF4444")); return;
        }
        if (!email.contains("@")) {
            loginStatus.setText("❌ Неверный email"); loginStatus.setTextColor(Color.parseColor("#FF4444")); return;
        }
        loginStatus.setText("⏳ Входим..."); loginStatus.setTextColor(Color.parseColor("#AAAAAA"));
        new Handler().postDelayed(() -> {
            userEmail = email;
            prefs.edit().putString("email", email).putString("regdate", getTodayDate()).apply();
            loginStatus.setText("✅ Успешно!"); loginStatus.setTextColor(Color.parseColor("#34D399"));
            new Handler().postDelayed(() -> showScreen(screenKey), 800);
        }, 1200);
    }

    void checkKey(String key, Button btn) {
        if (key.length() < 6) {
            keyStatus.setText("❌ Ключ слишком короткий!"); keyStatus.setTextColor(Color.parseColor("#FF4444")); return;
        }
        keyStatus.setText("⏳ Проверяем ключ..."); keyStatus.setTextColor(Color.parseColor("#AAAAAA"));
        btn.setEnabled(false);
        new AsyncTask<String, Void, int[]>() {
            protected int[] doInBackground(String... p) {
                try {
                    URL url = new URL(API + p[0]);
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(8000); c.setReadTimeout(8000);
                    BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder sb = new StringBuilder(); String l;
                    while ((l = br.readLine()) != null) sb.append(l);
                    String r = sb.toString();
                    if (r.contains("\"valid\":true") || r.contains("\"valid\": true")) {
                        int rem = 0;
                        int idx = r.indexOf("\"remaining\":"); if (idx<0) idx = r.indexOf("\"remaining\": ");
                        if (idx >= 0) { try { rem = Integer.parseInt(r.substring(idx+12).replaceAll("[^0-9].*","")); } catch(Exception e){} }
                        return new int[]{1, rem};
                    }
                } catch(Exception e) { e.printStackTrace(); }
                return new int[]{0, 0};
            }
            protected void onPostExecute(int[] res) {
                btn.setEnabled(true);
                if (res[0]==1 && res[1]>0) {
                    activeKey = key; keyExpire = now() + res[1];
                    prefs.edit().putString("key", key).putLong("expire", keyExpire).apply();
                    keyStatus.setText("✅ Ключ активирован!"); keyStatus.setTextColor(Color.parseColor("#34D399"));
                    new Handler().postDelayed(() -> showApp(), 800);
                } else {
                    keyStatus.setText("❌ Ключ недействителен или истёк!"); keyStatus.setTextColor(Color.parseColor("#FF4444"));
                }
            }
        }.execute(key);
    }

    void showApp() {
        showScreen(screenApp);
        showTab(0);
        startKeyTimer();
        updateProfile();
    }

    void showTab(int tab) {
        curTab = tab;
        tabHome.setVisibility(tab==0 ? View.VISIBLE : View.GONE);
        tabFaq.setVisibility(tab==1 ? View.VISIBLE : View.GONE);
        tabProfile.setVisibility(tab==2 ? View.VISIBLE : View.GONE);
        tabSettings.setVisibility(tab==3 ? View.VISIBLE : View.GONE);
        int ac = Color.parseColor("#A78BFA"), in = Color.parseColor("#555566");
        navHome.setTextColor(tab==0?ac:in); navFaq.setTextColor(tab==1?ac:in);
        navProfile.setTextColor(tab==2?ac:in); navSettings.setTextColor(tab==3?ac:in);
        if (tab==2) updateProfile();
    }

    void startKeyTimer() {
        if (keyTimer != null) keyTimer.cancel();
        long remaining = keyExpire - now();
        if (remaining <= 0) { showScreen(screenKey); return; }
        keyTimer = new CountDownTimer(remaining * 1000, 1000) {
            public void onTick(long ms) {
                long r = ms/1000, h = r/3600, m = (r%3600)/60, s = r%60;
                String t = String.format("%02d:%02d:%02d", h, m, s);
                mainTimer.setText(t);
                if (profileKeyTime != null) profileKeyTime.setText("Осталось: " + t);
            }
            public void onFinish() {
                activeKey = ""; keyExpire = 0;
                prefs.edit().remove("key").remove("expire").apply();
                mainTimer.setText("00:00:00");
                showScreen(screenKey);
                Toast.makeText(MainActivity.this, "⏰ Ключ истёк! Получи новый в боте.", Toast.LENGTH_LONG).show();
            }
        }.start();
        mainKeyShow.setText(activeKey);
    }

    void updateProfile() {
        if (profileEmail != null) {
            profileEmail.setText(userEmail.isEmpty() ? "Пользователь" : userEmail.split("@")[0]);
        }
        if (profileKeyVal != null) {
            profileKeyVal.setText(activeKey.isEmpty() ? "—" : activeKey);
        }
        if (profileKeyTime != null && !activeKey.isEmpty() && keyExpire > now()) {
            long r = keyExpire - now();
            profileKeyTime.setText("Осталось: " + String.format("%02d:%02d:%02d", r/3600, (r%3600)/60, r%60));
        }
    }

    void doLogout() {
        new AlertDialog.Builder(this).setTitle("Выйти?")
            .setMessage("Выйти из аккаунта?")
            .setPositiveButton("Выйти", (d,w) -> {
                userEmail=""; activeKey=""; keyExpire=0;
                prefs.edit().clear().apply();
                if (keyTimer!=null) keyTimer.cancel();
                showScreen(screenWelcome);
            })
            .setNegativeButton("Отмена", null).show();
    }

    void showDevMsg() {
        new AlertDialog.Builder(this).setTitle("🚧 В разработке")
            .setMessage("Эта функция скоро появится!\nСледи за обновлениями в @Yrener_Soft")
            .setPositiveButton("✈️ Открыть канал", (d,w) -> openUrl(TG_CH))
            .setNegativeButton("Закрыть", null).show();
    }

    void rebuildLangBtns(String[][] langs) {
        langGrid.removeAllViews();
        for (String[] lang : langs) {
            Button lb = btn(lang[1], curLang.equals(lang[0]) ? "accent" : "glass");
            lb.setTag(lang[0]);
            lb.setOnClickListener(v -> { curLang=(String)v.getTag(); prefs.edit().putString("lang",curLang).apply(); rebuildLangBtns(langs); });
            langGrid.addView(lb); space(langGrid, 6);
        }
    }

    void saveTheme() { prefs.edit().putString("theme", curTheme).apply(); }

    void applyTheme() {
        int bg;
        switch (curTheme) {
            case "light": bg = Color.parseColor("#F0F0F5"); break;
            case "ocean": bg = Color.parseColor("#0A1628"); break;
            default: bg = Color.parseColor("#08080F");
        }
        rootLayout.setBackgroundColor(bg);
    }

    void showScreen(LinearLayout s) {
        screenWelcome.setVisibility(s==screenWelcome ? View.VISIBLE : View.GONE);
        screenLogin.setVisibility(s==screenLogin ? View.VISIBLE : View.GONE);
        screenKey.setVisibility(s==screenKey ? View.VISIBLE : View.GONE);
        screenApp.setVisibility(s==screenApp ? View.VISIBLE : View.GONE);
    }

    void openUrl(String url) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }

    // =============================================
    // UI HELPERS
    // =============================================

    LinearLayout screen() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        l.setVisibility(View.GONE);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(20), dp(18), dp(20), dp(18));
        c.setBackground(roundBg("#12121A", 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        c.setLayoutParams(lp);
        return c;
    }

    LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return r;
    }

    LinearLayout logoFull(String sub) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(28));
        l.setLayoutParams(lp);
        TextView y = txt("Y", 36, "#FFFFFF");
        y.setTypeface(null, Typeface.BOLD);
        y.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ylp = new LinearLayout.LayoutParams(dp(80), dp(80));
        ylp.gravity = Gravity.CENTER_HORIZONTAL;
        y.setLayoutParams(ylp);
        y.setBackground(roundOvalBg());
        l.addView(y);
        space(l, 12);
        TextView name = txt("Yrener", 26, "#FFFFFF");
        name.setTypeface(null, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        l.addView(name);
        space(l, 4);
        TextView s = txt(sub, 12, "#888899");
        s.setGravity(Gravity.CENTER);
        l.addView(s);
        return l;
    }

    LinearLayout logoSmall() {
        LinearLayout r = row();
        TextView y = txt("Y", 18, "#FFFFFF");
        y.setTypeface(null, Typeface.BOLD);
        y.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ylp = new LinearLayout.LayoutParams(dp(40), dp(40));
        y.setLayoutParams(ylp);
        y.setBackground(roundBg("#6C63FF", 12));
        r.addView(y);
        space2(r, 10);
        TextView name = txt("Yrener", 18, "#FFFFFF");
        name.setTypeface(null, Typeface.BOLD);
        r.addView(name);
        return r;
    }

    Button btn(String text, String type) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setPadding(dp(16), 0, dp(16), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.setMargins(0, 0, 0, 0);
        b.setLayoutParams(lp);
        switch (type) {
            case "primary": b.setBackground(gradBg("#6C63FF","#A78BFA")); b.setTextColor(Color.WHITE); break;
            case "glass":   b.setBackground(roundBg("#1A1A2A",12)); b.setTextColor(Color.parseColor("#CCCCDD")); break;
            case "white":   b.setBackground(roundBg("#FFFFFF",12)); b.setTextColor(Color.BLACK); break;
            case "tg":      b.setBackground(roundBg("#0088CC",12)); b.setTextColor(Color.WHITE); break;
            case "accent":  b.setBackground(roundBg("#2A1A4A",12)); b.setTextColor(Color.parseColor("#A78BFA")); break;
            case "outline_tg": b.setBackground(roundBg("#0A1A2A",12)); b.setTextColor(Color.parseColor("#0088CC")); break;
        }
        b.setTextSize(14);
        return b;
    }

    Button navBtn(String icon, String label) {
        Button b = new Button(this);
        b.setText(icon + "\n" + label);
        b.setAllCaps(false);
        b.setTextSize(10);
        b.setTextColor(Color.parseColor("#555566"));
        b.setBackground(null);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1));
        b.setGravity(Gravity.CENTER);
        return b;
    }

    TextView txt(String t, int sp, String color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(Color.parseColor(color));
        v.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        return v;
    }

    TextView cardTitle(String t) {
        TextView v = txt(t, 17, "#FFFFFF");
        v.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(4));
        v.setLayoutParams(lp);
        return v;
    }

    TextView cardSub(String t) {
        TextView v = txt(t, 13, "#888899");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(4));
        v.setLayoutParams(lp);
        return v;
    }

    TextView pageTitle(String t) {
        TextView v = txt(t, 22, "#FFFFFF");
        v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    TextView sectionTitle(String t) {
        TextView v = txt(t.toUpperCase(), 11, "#666677");
        v.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(12), 0, dp(6));
        v.setLayoutParams(lp);
        return v;
    }

    TextView inputLabel(String t) {
        TextView v = txt(t, 13, "#888899");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(6));
        v.setLayoutParams(lp);
        return v;
    }

    EditText inputField(String hint, boolean pass) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.parseColor("#555566"));
        e.setTextColor(Color.WHITE);
        e.setTextSize(15);
        e.setPadding(dp(16), dp(14), dp(16), dp(14));
        e.setBackground(roundBg("#1A1A2A", 10));
        e.setSingleLine(true);
        if (pass) e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, 0, 0, 0);
        e.setLayoutParams(lp);
        return e;
    }

    View divider(String label) {
        LinearLayout r = row();
        View l = new View(this); l.setBackgroundColor(Color.parseColor("#222233"));
        l.setLayoutParams(new LinearLayout.LayoutParams(0, dp(1), 1));
        TextView t = txt("  " + label + "  ", 12, "#555566");
        View r2 = new View(this); r2.setBackgroundColor(Color.parseColor("#222233"));
        r2.setLayoutParams(new LinearLayout.LayoutParams(0, dp(1), 1));
        r.addView(l); r.addView(t); r.addView(r2);
        return r;
    }

    View faqItem(String q, String a) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(roundBg("#12121A", 10));
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
        wlp.setMargins(0, 0, 0, dp(8));
        wrap.setLayoutParams(wlp);

        LinearLayout qRow = row();
        qRow.setPadding(dp(14), dp(14), dp(14), dp(14));
        TextView qText = txt("❓ " + q, 14, "#FFFFFF");
        qText.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = txt("▾", 16, "#888899");
        qRow.addView(qText); qRow.addView(arrow);
        wrap.addView(qRow);

        TextView aText = txt("💡 " + a, 13, "#AAAAAA");
        aText.setPadding(dp(14), 0, dp(14), 0);
        aText.setMaxHeight(0);
        aText.setVisibility(View.GONE);
        aText.setLineSpacing(dp(4), 1f);
        wrap.addView(aText);

        qRow.setOnClickListener(v -> {
            if (aText.getVisibility() == View.GONE) {
                aText.setVisibility(View.VISIBLE);
                aText.setPadding(dp(14), dp(4), dp(14), dp(14));
                arrow.setText("▴");
            } else {
                aText.setVisibility(View.GONE);
                arrow.setText("▾");
            }
        });
        return wrap;
    }

    View listItem(String icon, String title, String sub, boolean last) {
        LinearLayout r = row();
        r.setPadding(0, dp(12), 0, dp(12));
        if (!last) {
            // border bottom via margin
        }
        TextView ic = txt(icon, 18, "#FFFFFF");
        ic.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(38), dp(38));
        ic.setLayoutParams(ilp);
        ic.setBackground(roundBg("#1A1A2A", 10));
        ic.setGravity(Gravity.CENTER);
        r.addView(ic);
        space2(r, 12);
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        TextView t = txt(title, 15, "#FFFFFF");
        TextView s = txt(sub, 12, "#888899");
        info.addView(t); info.addView(s);
        r.addView(info);
        return r;
    }

    View clickItem(String icon, String title, Runnable action) {
        LinearLayout r = row();
        r.setPadding(0, dp(14), 0, dp(14));
        r.setClickable(true);
        r.setFocusable(true);
        r.setOnClickListener(v -> action.run());
        TextView ic = txt(icon, 18, "#FFFFFF");
        ic.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(38), dp(38));
        ic.setLayoutParams(ilp);
        ic.setBackground(roundBg("#1A1A2A", 10));
        r.addView(ic);
        space2(r, 12);
        TextView t = txt(title, 15, "#FFFFFF");
        t.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(t);
        TextView arr = txt("›", 20, "#555566");
        r.addView(arr);
        return r;
    }

    void space(LinearLayout parent, int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dp)));
        parent.addView(v);
    }

    void space2(LinearLayout parent, int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(dp), -1));
        parent.addView(v);
    }

    android.graphics.drawable.GradientDrawable roundBg(String color, int r) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(Color.parseColor(color));
        d.setCornerRadius(dp(r));
        return d;
    }

    android.graphics.drawable.GradientDrawable roundOvalBg() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColors(new int[]{Color.parseColor("#6C63FF"), Color.parseColor("#A78BFA")});
        d.setGradientType(android.graphics.drawable.GradientDrawable.LINEAR_GRADIENT);
        d.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TL_BR);
        return d;
    }

    android.graphics.drawable.GradientDrawable gradBg(String c1, String c2) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColors(new int[]{Color.parseColor(c1), Color.parseColor(c2)});
        d.setGradientType(android.graphics.drawable.GradientDrawable.LINEAR_GRADIENT);
        d.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TL_BR);
        d.setCornerRadius(dp(12));
        return d;
    }

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    String getDeviceName() {
        return android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + " (Android " + android.os.Build.VERSION.RELEASE + ")";
    }

    String getTodayDate() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        return c.get(java.util.Calendar.DAY_OF_MONTH) + "." + (c.get(java.util.Calendar.MONTH)+1) + "." + c.get(java.util.Calendar.YEAR);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (keyTimer != null) keyTimer.cancel();
    }
}
